<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Students;

class StudentsController extends Controller
{
    public function index(){
        // menampilkan semua data
        $students = students::all();
		// $no_students = count($students) > 0;

		if (!empty($students)) {
			$response = [
				'message' => 'Mendapatkan semua data students',
				'data' => $students,
			];
			return response()->json($response, 200);
		} else {
			$response = [
				'message' => 'Data is Empty'
			];
			return response()->json($response, 200);
		}
    }
    // menambah data
    public function store(Request $request){
        $input = ['nama'=> $request->nama,
        'nim' => $request->nim,
        'email' => $request->email,
        'jurusan' => $request->jurusan];

    
        $students = students::create($input);

        $data1 = [
            'message' => "data berhasil di tambahkan",
            'data' => $students
        ];
        return response()->json($data1, 201);
    }

    // menampilkan per id
    public function show($id){
        $students = students::find($id);
        if ($students){
        $data2 = [
            "massage" => "detail data",
            'data' => $students
        ];
        return response()->json($data2, 200);
    } else{
        $data = [
            'massage' => 'Data Not Found'
        ];
        return response()->json($data, 404);
    }
    }
    
// mengubah data
    public function update(Request $request, $id){
        $students = students::find($id);
        if ($students){
        $students->update([
            'nama'=> $request->nama ?? $students->nama,
        'nim' => $request->nim ?? $students->nim,
        'email' => $request->email ?? $students->email,
        'jurusan' => $request->jurusan ?? $students->jurusan
        ]);

        $data = ['message' => "Student is updated",
        "data" => $students
    ];
    return response()->json($data,200);
    }else{
        $data = [
            'message' => 'data not found'
        ];
        return response()->json($data, 404);
    }
    }

    public function destroy($id)
    {
        // untuk menghapus data students menggunakan
        $students = students::find($id);

        if ($students){
            $students->delete();

            $data = ['message' => "Student is deleted"];
    return response()->json($data,200);
    }else{
        $data = [
            'message' => 'data not found'
        ];
        return response()->json($data, 404);
    }
    }
}